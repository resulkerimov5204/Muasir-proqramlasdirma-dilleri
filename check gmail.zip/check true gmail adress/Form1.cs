﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace check_true_gmail_adress
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static Dictionary<string, string> users = new Dictionary<string, string>();

       
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string newUser = textBox1.Text.Trim();
            string newPass = textBox2.Text.Trim();

           
            if (string.IsNullOrWhiteSpace(newUser) || string.IsNullOrWhiteSpace(newPass))
            {
                MessageBox.Show("Xahiş olunur həm istifadəçi adını, həm də şifrəni daxil edin.", "Bildiriş", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            
            if (!IsValidGmailAddress(newUser))
            {
                MessageBox.Show("Düzgün bir Gmail ünvanı daxil edin (məsələn: ad@gmail.com).", "Bildiriş", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            if (users.ContainsKey(newUser))
            {
                MessageBox.Show("Bu istifadəçi artıq mövcuddur.", "Bildiriş", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {


                users.Add(newUser, newPass);
                MessageBox.Show("İstifadəçi uğurla qeydiyyatdan keçdi.", "Bildiriş", MessageBoxButtons.OK, MessageBoxIcon.Information);

                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private bool IsValidGmailAddress(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            
            string pattern = @"^[a-zA-Z0-9.]+@gmail\.com$";

            return Regex.IsMatch(email, pattern, RegexOptions.IgnoreCase);
        }
    }
}